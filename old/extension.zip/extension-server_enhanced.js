// Enhanced Extension Server V2.1
// Added: Button click command support

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');

const PORT = 9999;
const PRICE_FILE = path.join(os.tmpdir(), 'bidhelper_dom_estimate.txt');
const CURRENT_ASK_PRICE_FILE = path.join(os.tmpdir(), 'bidhelper_current_ask_price.txt');
const BUTTON_STATE_FILE = path.join(os.tmpdir(), 'bidhelper_button_state.txt');
const BUTTON_STATES_FILE = path.join(os.tmpdir(), 'bidhelper_button_states.txt');
const INTERNET_BID_PRICE_FILE = path.join(os.tmpdir(), 'bidhelper_internet_bid_price.txt');
const PRICE_SNAPSHOT_FILE = path.join(os.tmpdir(), 'bidhelper_price_snapshot.json');
const LITE_MODE_FLAG_FILE = path.join(os.tmpdir(), 'bidhelper_lite_mode.txt');

// Command Queue
let pendingCommands = [];
let nextCommandId = 1;
let commandResults = new Map();

let latestLotId = '';
let activeLotId = '';
let lotSnapshots = Object.create(null);
let latestEstimatePrice = '';
let latestInternetText = '';
let latestPriceHistory = [];  // Store price history/scroller data

function writePriceSnapshot(extra = {}) {
  try {
    fs.writeFileSync(PRICE_SNAPSHOT_FILE, JSON.stringify({
      estimate: latestEstimatePrice || '',
      internet: latestInternetText || '',
      activeLotId: activeLotId || latestLotId || '',
      updatedAt: Date.now(),
      ...extra
    }));
  } catch (_) { }
}

function normalizeLotId(value) {
  if (value === undefined || value === null) return '';
  return String(value).trim();
}

function getSelectedLotId(explicitLotId = '') {
  return normalizeLotId(explicitLotId) || activeLotId || latestLotId || '';
}

function getSnapshotForLot(lotId) {
  const selectedLotId = getSelectedLotId(lotId);
  const snapshot = selectedLotId ? lotSnapshots[selectedLotId] : null;
  return {
    states: snapshot?.states || {},
    updatedAt: snapshot?.updatedAt || 0,
    activeLotId: selectedLotId
  };
}

function writeLegacyButtonState(snapshot) {
  try {
    const isVisible = Boolean(snapshot?.states?.internet?.ready);
    fs.writeFileSync(BUTTON_STATE_FILE, isVisible ? 'visible' : 'hidden');
  } catch (_) { }
}

// ========================================
// ENHANCED: BUTTON CLICK HELPERS
// ========================================

/**
 * Queue a button click command
 * @param {string} type - Command type (CLICK_BUTTON, CLICK_PRIMARY)
 * @param {Object} params - Command parameters
 * @returns {string} commandId
 */
function queueClickCommand(type, params) {
  const cmdId = String(nextCommandId++);
  pendingCommands.push({
    id: cmdId,
    type,
    ...params
  });
  return cmdId;
}

/**
 * Wait for command result with timeout
 * @param {string} commandId
 * @param {number} timeoutMs
 * @returns {Promise<Object>}
 */
function waitForCommandResult(commandId, timeoutMs = 5000) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    const checkInterval = setInterval(() => {
      const result = commandResults.get(commandId);
      
      if (result && result.status !== 'pending') {
        clearInterval(checkInterval);
        commandResults.delete(commandId);
        resolve(result);
      } else if (Date.now() - startTime > timeoutMs) {
        clearInterval(checkInterval);
        commandResults.delete(commandId);
        resolve({ success: false, status: 'timeout', error: 'Command timed out' });
      }
    }, 50);
  });
}

// ========================================
// HTTP SERVER
// ========================================

http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }

  const requestUrl = new URL(req.url, `http://127.0.0.1:${PORT}`);
  const pathname = requestUrl.pathname;

  // === GET ENDPOINTS ===
  if (req.method === 'GET') {
    // Button states
    if (pathname === '/button-states' || pathname === '/active-state') {
      const selectedLotId = requestUrl.searchParams.get('lotId') || requestUrl.searchParams.get('id') || '';
      const snapshot = getSnapshotForLot(selectedLotId);
      res.end(JSON.stringify({ ...snapshot, success: true }));
      return;
    }

    // Price state (price history scroller data)
    if (pathname === '/price-state') {
      const selectedLotId = requestUrl.searchParams.get('lotId') || requestUrl.searchParams.get('id') || '';
      const snapshot = selectedLotId ? lotSnapshots[selectedLotId] : null;
      res.end(JSON.stringify({
        activeLotId: getSelectedLotId(selectedLotId),
        currentEstimatePrice: latestEstimatePrice || '',
        internetBidText: latestInternetText || '',
        priceHistory: latestPriceHistory || [],
        updatedAt: snapshot?.updatedAt || 0,
        success: true
      }));
      return;
    }

    // Pending commands (for extension to poll)
    if (pathname === '/get-pending-commands') {
      res.end(JSON.stringify({ commands: pendingCommands, success: true }));
      return;
    }

    // Command status check
    if (pathname === '/set-current-ask-status') {
      const id = requestUrl.searchParams.get('id');
      const result = commandResults.get(id) || { status: 'pending' };
      res.end(JSON.stringify(result));
      return;
    }

    // Lite mode status
    if (pathname === '/lite-mode-status') {
      const enabled = fs.existsSync(LITE_MODE_FLAG_FILE);
      res.end(JSON.stringify({ enabled, success: true }));
      return;
    }

    // === NEW: Click button endpoint (GET for simple clicks) ===
    if (pathname === '/click-button') {
      const buttonName = requestUrl.searchParams.get('button');
      const keywords = requestUrl.searchParams.get('keywords');
      const selector = requestUrl.searchParams.get('selector');
      
      const cmdId = queueClickCommand('CLICK_PRIMARY', { buttonName });
      
      // Wait for result
      waitForCommandResult(cmdId, 3000).then(result => {
        res.end(JSON.stringify(result));
      });
      return;
    }
  }

  // === POST ENDPOINTS ===
  let body = '';
  req.on('data', c => body += c);
  req.on('end', () => {
    try {
      const d = JSON.parse(body || '{}');

      // Button states update (from extension)
      if (pathname === '/button-states') {
        const lotId = normalizeLotId(d.lotId);
        if (lotId) {
          latestLotId = lotId;
          activeLotId = lotId;

          lotSnapshots[lotId] = {
            states: d.states || {},
            updatedAt: Date.now()
          };

          if (activeLotId === lotId) {
            writeLegacyButtonState({ states: d.states || {} });
            fs.writeFileSync(BUTTON_STATES_FILE, JSON.stringify(d.states || {}));
            
            const internetText = d.states?.internet?.text || '';
            latestInternetText = String(internetText);
            fs.writeFileSync(INTERNET_BID_PRICE_FILE, String(internetText));
            writePriceSnapshot();
          }
        }
        res.end(JSON.stringify({ success: true }));
        return;
      }

      // Set current ask (existing)
      if (pathname === '/set-current-ask') {
        const cmdId = String(nextCommandId++);
        pendingCommands.push({
          id: cmdId,
          type: 'SET_CURRENT_ASK',
          value: d.value,
          selectOnly: !!d.selectOnly
        });
        res.end(JSON.stringify({ success: true, commandId: cmdId }));
        return;
      }

      // === NEW: Click button command (POST for complex clicks) ===
      if (pathname === '/click-button-command') {
        const cmdId = queueClickCommand('CLICK_BUTTON', {
          selector: d.selector,
          exact: d.exact,
          keywords: d.keywords
        });
        res.end(JSON.stringify({ success: true, commandId: cmdId }));
        return;
      }

      // === NEW: Click primary button ===
      if (pathname === '/click-primary') {
        const cmdId = queueClickCommand('CLICK_PRIMARY', {
          buttonName: d.buttonName
        });
        res.end(JSON.stringify({ success: true, commandId: cmdId }));
        return;
      }

      // Command result (from extension)
      if (pathname === '/command-result') {
        const cmdId = d.id;
        if (cmdId) {
          commandResults.set(cmdId, {
            success: d.success,
            status: d.success ? 'completed' : 'failed',
            error: d.error,
            coords: d.coords // For FIND_BUTTON_COORDS
          });
          
          // Remove from pending queue
          pendingCommands = pendingCommands.filter(cmd => cmd.id !== cmdId);
        }
        res.end(JSON.stringify({ success: true }));
        return;
      }

      // Price update (from extension)
      if (pathname === '/price-update') {
        const price = d.price || '';
        latestEstimatePrice = price;
        
        fs.writeFileSync(PRICE_FILE, price);
        fs.writeFileSync(CURRENT_ASK_PRICE_FILE, price);
        writePriceSnapshot();
        
        res.end(JSON.stringify({ success: true }));
        return;
      }

      // Price state update (price history scroller data from extension)
      if (pathname === '/price-state') {
        if (d.priceHistory) {
          latestPriceHistory = Array.isArray(d.priceHistory) ? d.priceHistory : [];
        }
        if (d.currentEstimatePrice) {
          latestEstimatePrice = d.currentEstimatePrice;
        }
        if (d.internetBidText) {
          latestInternetText = d.internetBidText;
        }
        writePriceSnapshot({ priceHistory: latestPriceHistory });
        res.end(JSON.stringify({ success: true }));
        return;
      }

      // Unknown endpoint
      res.statusCode = 404;
      res.end(JSON.stringify({ success: false, error: 'Unknown endpoint' }));
      
    } catch (err) {
      res.statusCode = 500;
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
  });

}).listen(PORT, '127.0.0.1', () => {
  console.log(`[ExtensionServer] Enhanced server listening on http://localhost:${PORT}`);
  console.log(`[ExtensionServer] New features:`);
  console.log(`  - POST /click-primary {"buttonName": "sold|next|internet|etc"}`);
  console.log(`  - POST /click-button-command {"selector": ".btn", "keywords": ["text"]}`);
  console.log(`  - GET  /click-button?button=sold`);
});
