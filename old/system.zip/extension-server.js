const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const WebSocket = require('ws');

const PORT = 9999;
const PRICE_FILE = path.join(os.tmpdir(), 'bidhelper_dom_estimate.txt');
const CURRENT_ASK_PRICE_FILE = path.join(os.tmpdir(), 'bidhelper_current_ask_price.txt');
const BUTTON_STATE_FILE = path.join(os.tmpdir(), 'bidhelper_button_state.txt');
const BUTTON_STATES_FILE = path.join(os.tmpdir(), 'bidhelper_button_states.txt');
const INTERNET_BID_PRICE_FILE = path.join(os.tmpdir(), 'bidhelper_internet_bid_price.txt');
const PRICE_SNAPSHOT_FILE = path.join(os.tmpdir(), 'bidhelper_price_snapshot.json');
const LITE_MODE_FLAG_FILE = path.join(os.tmpdir(), 'bidhelper_lite_mode.txt');

// Command Queue for DOM Injection
let pendingCommands = [];
let nextCommandId = 1;
let commandResults = new Map();

// Fast flash state — single variable, no queue, extension polls /get-flash every 100ms
let latestFlash = { seq: 0, buttonName: '', duration: 400 };
let flashSeq = 0;

// Latest calc price from the calculator extension
let latestCalcPrice = { rawEstimate: 0, bidEstimate: 0, divisor: 1.3, lotId: '', timestamp: 0 };

let latestLotId = '';
let activeLotId = '';
let lotSnapshots = Object.create(null);
let latestEstimatePrice = '';
let latestInternetText = '';

// ============================================
// LOT SESSION STATE + EXPLOIT DETECTION
// ============================================

const SCROLLER_LOG_FILE = path.join('C:\\LiveAuction\\system', 'scrollerlog.txt');

// Current lot session
let lotSession = {
  lotNum: '',          // e.g. "816R"
  openedAt: 0,         // timestamp when LOT_OPENED received
  safe: true,          // false = exploit detected
  exploitReason: '',   // human-readable reason
  exploitMsg: '',      // raw scroller message that triggered it
  exploitTime: 0       // timestamp of exploit
};

// PRE_SOLD signal - bot sends this BEFORE clicking Sold button
let expectedSale = {
  lotNum: '',          // e.g. "971R"
  timestamp: 0         // when PRE_SOLD was sent
};

// Append a line to scrollerlog.txt, pruning entries older than 24hrs
function writeScrollerLog(lotNum, message) {
  try {
    const now = Date.now();
    const dateStr = new Date(now).toISOString().replace('T', ' ').slice(0, 19);
    const line = `[${dateStr}] [Lot ${lotNum || '?'}] ${message}\n`;

    // Append new line
    fs.appendFileSync(SCROLLER_LOG_FILE, line);

    // Prune lines older than 24hrs (run every ~100 writes to avoid constant file reads)
    if (Math.random() < 0.01) {
      pruneScrollerLog();
    }
  } catch (e) {
    console.error('[ScrollerLog] Write error:', e.message);
  }
}

function pruneScrollerLog() {
  try {
    if (!fs.existsSync(SCROLLER_LOG_FILE)) return;
    const cutoff = Date.now() - (24 * 60 * 60 * 1000); // 24 hours ago
    const lines = fs.readFileSync(SCROLLER_LOG_FILE, 'utf8').split('\n');
    const kept = lines.filter(line => {
      // Parse timestamp from "[2026-09-15 14:23:01]"
      const m = line.match(/^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]/);
      if (!m) return false; // drop malformed lines
      const ts = new Date(m[1]).getTime();
      return ts >= cutoff;
    });
    fs.writeFileSync(SCROLLER_LOG_FILE, kept.join('\n') + (kept.length ? '\n' : ''));
    console.log(`[ScrollerLog] Pruned to ${kept.length} lines`);
  } catch (e) {
    console.error('[ScrollerLog] Prune error:', e.message);
  }
}

function handleLotEvent(d) {
  const { type, lotNum, message, price, timestamp } = d;

  // Always log everything to scrollerlog.txt
  writeScrollerLog(lotNum, message);

  switch (type) {
    case 'LOT_OPENED':
      // New lot session - reset safety state
      lotSession = {
        lotNum,
        openedAt: timestamp || Date.now(),
        safe: true,
        exploitReason: '',
        exploitMsg: '',
        exploitTime: 0
      };
      console.log(`[Session] Lot ${lotNum} opened - new session started`);
      break;

    case 'LOT_SOLD_OK':
      // Bot-authorised sale (Competing Bid or Internet Bid) - safe
      console.log(`[Session] Lot ${lotNum} sold OK at $${price} - authorised`);
      break;

    case 'EXPLOIT_MANUAL_SALE':
      // Sold without "Competing Bid" or "Internet Bid" in the message
      lotSession.safe = false;
      lotSession.exploitReason = `Manual sale detected: Lot ${lotNum} sold for $${price} without bot authorisation`;
      lotSession.exploitMsg = message;
      lotSession.exploitTime = timestamp || Date.now();
      console.error(`[EXPLOIT] ${lotSession.exploitReason}`);
      writeScrollerLog(lotNum, `*** EXPLOIT DETECTED: ${lotSession.exploitReason} ***`);
      break;

    case 'EXPLOIT_MANUAL_PASS':
      // Someone manually clicked Pass
      lotSession.safe = false;
      lotSession.exploitReason = `Manual pass detected: Lot ${lotNum} passed without bot authorisation`;
      lotSession.exploitMsg = message;
      lotSession.exploitTime = timestamp || Date.now();
      console.error(`[EXPLOIT] ${lotSession.exploitReason}`);
      writeScrollerLog(lotNum, `*** EXPLOIT DETECTED: ${lotSession.exploitReason} ***`);
      break;

    case 'LOT_CLOSED':
      console.log(`[Session] Lot ${lotNum} closed`);
      break;

    case 'LOG':
    default:
      // Normal scroller messages (ask $375, Last Call, Going Once etc.) - already logged above
      break;
  }
}

// ============================================
// PRICE SYNC STATE
// ============================================
let canonicalPrice = {
  estimate: 0,
  currentAsk: 0,
  lotId: '',
  timestamp: 0,
  verified: false,
  sources: {
    calculator: null,
    bot: null
  }
};

let biddingBlocked = false;
let blockReason = '';
const wsClients = new Set();
let lastPriceVerification = {
  verified: false,
  reason: 'WAITING_FOR_SOURCES',
  timestamp: 0
};
let lastSyncedEstimate = {
  synced: false,
  source: '',
  rawEstimate: 0,
  bidEstimate: 0,
  divisor: 0,
  lotId: '',
  timestamp: 0
};

let stats = {
  totalVerifications: 0,
  successfulVerifications: 0,
  mismatches: 0,
  lastMismatch: null,
  uptimeStart: Date.now()
};

function writePriceSnapshot(extra = {}) {
  try {
    fs.writeFileSync(PRICE_SNAPSHOT_FILE, JSON.stringify({
      estimate: latestEstimatePrice || '',
      internet: latestInternetText || '',
      activeLotId: activeLotId || latestLotId || '',
      updatedAt: Date.now(),
      ...extra
    }));
  } catch (_) { }
}

function normalizeLotId(value) {
  if (value === undefined || value === null) return '';
  return String(value).trim();
}

function getSelectedLotId(explicitLotId = '') {
  return normalizeLotId(explicitLotId) || activeLotId || latestLotId || '';
}

function getSnapshotForLot(lotId) {
  const selectedLotId = getSelectedLotId(lotId);
  const snapshot = selectedLotId ? lotSnapshots[selectedLotId] : null;

  return {
    states: snapshot?.states || {},
    updatedAt: snapshot?.updatedAt || 0,
    activeLotId: selectedLotId
  };
}

function writeLegacyButtonState(snapshot) {
  try {
    const isVisible = Boolean(snapshot?.states?.internet?.ready);
    fs.writeFileSync(BUTTON_STATE_FILE, isVisible ? 'visible' : 'hidden');
  } catch (_) { }
}

function parsePriceValue(value) {
  if (typeof value === 'number') return value;
  if (typeof value !== 'string') return 0;
  const parsed = parseInt(value.replace(/[$,\s]/g, ''), 10);
  return Number.isFinite(parsed) ? parsed : 0;
}

function getCanBidState() {
  const now = Date.now();
  const canonicalAgeMs = canonicalPrice.timestamp ? now - canonicalPrice.timestamp : Number.POSITIVE_INFINITY;
  const calc = canonicalPrice.sources.calculator;
  const bot = canonicalPrice.sources.bot;
  const hasBothSources = !!calc && !!bot;
  const hasFreshCanonical = canonicalPrice.verified && canonicalAgeMs <= 5000;
  const computedBlocked = biddingBlocked || !hasBothSources || !hasFreshCanonical;
  const computedReason = biddingBlocked
    ? blockReason
    : (!hasBothSources ? 'WAITING_FOR_SOURCES' : (!hasFreshCanonical ? 'NO_FRESH_VERIFICATION' : ''));

  return {
    blocked: computedBlocked,
    reason: computedReason,
    verified: !computedBlocked,
    canonicalAgeMs: Number.isFinite(canonicalAgeMs) ? canonicalAgeMs : null,
    sources: {
      calculator: calc ? { lotId: calc.lotId, estimate: calc.estimate, ageMs: now - calc.timestamp } : null,
      bot: bot ? { lotId: bot.lotId, estimate: bot.estimate, ageMs: now - bot.timestamp } : null
    },
    timestamp: now
  };
}

function isValidPriceSyncLotId(lotId) {
  const value = normalizeLotId(lotId);
  return !!value && value !== '-' && !/^lot\s*:?#?$/i.test(value);
}

// ============================================
// PRICE SYNC HANDLERS
// ============================================

function handlePriceUpdate(msg) {
  const { source, estimate, currentAsk, lotId, strategy, hash } = msg;
  if (source !== 'calculator' && source !== 'bot') {
    console.warn(`[PriceSync] Ignoring invalid source: ${source}`);
    return;
  }
  
  console.log(`[PriceSync] ${source}: Est=$${estimate}, Ask=$${currentAsk}, Lot=${lotId}, Strategy=${strategy}`);
  
  canonicalPrice.sources[source] = {
    estimate: estimate || 0,
    currentAsk: currentAsk || 0,
    lotId: lotId || '',
    strategy: strategy || 0,
    hash: hash || 0,
    timestamp: Date.now()
  };

  if (!isValidPriceSyncLotId(lotId)) {
    biddingBlocked = true;
    blockReason = 'INVALID_LOT_ID';
    lastPriceVerification = {
      verified: false,
      reason: blockReason,
      source,
      lotId,
      timestamp: Date.now()
    };
    broadcastToClients({
      type: 'PRICE_UPDATE',
      canonicalPrice,
      biddingBlocked,
      blockReason
    });
    return;
  }
  
  const calc = canonicalPrice.sources.calculator;
  const bot = canonicalPrice.sources.bot;
  const now = Date.now();
  
  if (!calc || !bot) {
    lastPriceVerification = {
      verified: false,
      reason: 'WAITING_FOR_SOURCES',
      calculator: calc,
      bot,
      timestamp: now
    };
    return;
  }
  
  const calcAge = now - calc.timestamp;
  const botAge = now - bot.timestamp;
  
  if (calcAge > 2000 || botAge > 2000) {
    console.log(`[PriceSync] Stale data: calc=${calcAge}ms, bot=${botAge}ms`);
    lastPriceVerification = {
      verified: false,
      reason: 'STALE_SOURCE_DATA',
      calculatorAgeMs: calcAge,
      botAgeMs: botAge,
      timestamp: now
    };
    return;
  }
  
  if (calc.lotId !== bot.lotId) {
    console.log(`[PriceSync] Lot ID mismatch: calc=${calc.lotId}, bot=${bot.lotId}`);
    biddingBlocked = true;
    blockReason = 'LOT_ID_MISMATCH';
    lastPriceVerification = {
      verified: false,
      reason: blockReason,
      calculator: calc,
      bot,
      timestamp: now
    };
    return;
  }
  
  const estimateMatch = calc.estimate === bot.estimate;
  const askMatch = calc.currentAsk === bot.currentAsk;
  const strategyMatch = calc.strategy === bot.strategy;
  const hashMatch = calc.hash === bot.hash;
  
  stats.totalVerifications++;
  
  if (estimateMatch) {
    console.log(`✅ VERIFIED: Est=$${calc.estimate}, Ask=$${calc.currentAsk}, Lot=${calc.lotId}`);
    
    canonicalPrice = {
      estimate: calc.estimate,
      currentAsk: calc.currentAsk || bot.currentAsk || 0,
      lotId: calc.lotId,
      diagnostics: { askMatch, strategyMatch, hashMatch },
      timestamp: now,
      verified: true,
      sources: { calculator: calc, bot: bot }
    };
    
    biddingBlocked = false;
    blockReason = '';
    stats.successfulVerifications++;
    lastPriceVerification = {
      verified: true,
      reason: '',
      estimate: calc.estimate,
      currentAsk: calc.currentAsk || bot.currentAsk || 0,
      lotId: calc.lotId,
      diagnostics: { askMatch, strategyMatch, hashMatch },
      timestamp: now
    };
    
  } else {
    console.log(`❌ MISMATCH: Est(${calc.estimate}≠${bot.estimate}) Ask(${calc.currentAsk}≠${bot.currentAsk}) Strat(${calc.strategy}≠${bot.strategy}) Hash(${calc.hash}≠${bot.hash})`);
    
    biddingBlocked = true;
    blockReason = `Price mismatch: calc=$${calc.estimate}/$${calc.currentAsk} bot=$${bot.estimate}/$${bot.currentAsk}`;
    stats.mismatches++;
    stats.lastMismatch = {
      calc: { estimate: calc.estimate, currentAsk: calc.currentAsk, strategy: calc.strategy },
      bot: { estimate: bot.estimate, currentAsk: bot.currentAsk, strategy: bot.strategy },
      timestamp: now
    };
    lastPriceVerification = {
      verified: false,
      reason: 'PRICE_MISMATCH',
      calculator: calc,
      bot,
      timestamp: now
    };
  }
  
  broadcastToClients({
    type: 'PRICE_UPDATE',
    canonicalPrice,
    biddingBlocked,
    blockReason
  });
}

function broadcastToClients(msg) {
  const json = JSON.stringify(msg);
  wsClients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(json);
    }
  });
}

// ============================================
// HTTP SERVER (existing endpoints + new ones)
// ============================================

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }

  const requestUrl = new URL(req.url, `http://127.0.0.1:${PORT}`);
  const pathname = requestUrl.pathname;

  // --- GET ENDPOINTS ---
  if (req.method === 'GET') {
    // NEW: Price sync endpoint for AHK bot
    if (pathname === '/can-bid') {
      res.end(JSON.stringify(getCanBidState()));
      return;
    }

    if (pathname === '/get-canonical-price') {
      res.end(JSON.stringify({
        success: true,
        ...canonicalPrice,
        canonicalPrice,
        biddingBlocked,
        blockReason
      }));
      return;
    }

    if (pathname === '/sync-estimate') {
      res.end(JSON.stringify(lastSyncedEstimate));
      return;
    }

    if (pathname === '/last-price-verification') {
      res.end(JSON.stringify(lastPriceVerification, null, 2));
      return;
    }

    if (pathname === '/stats') {
      res.end(JSON.stringify({
        stats,
        uptime: Date.now() - stats.uptimeStart,
        wsClients: wsClients.size,
        currentState: {
          biddingBlocked,
          blockReason,
          canonicalPrice,
          canBid: getCanBidState(),
          lastPriceVerification
        },
        success: true
      }));
      return;
    }

    if (pathname === '/health') {
      res.end(JSON.stringify({ status: 'ok', timestamp: Date.now() }));
      return;
    }

    // Lot session status - AHK polls this before every F8/F9 bid
    if (pathname === '/session-status') {
      res.end(JSON.stringify({
        safe:          lotSession.safe,
        lotNum:        lotSession.lotNum,
        openedAt:      lotSession.openedAt,
        exploitReason: lotSession.exploitReason,
        exploitMsg:    lotSession.exploitMsg,
        exploitTime:   lotSession.exploitTime,
        timestamp:     Date.now(),
        success:       true
      }));
      return;
    }

    // Check if sale was pre-authorized by bot (for extension)
    if (pathname === '/check-pre-sold') {
      const lotNum = requestUrl.searchParams.get('lotNum') || '';
      const now = Date.now();
      const isExpected = (now - expectedSale.timestamp < 2000) && expectedSale.lotNum === lotNum;
      
      res.end(JSON.stringify({
        expected: isExpected,
        lotNum: expectedSale.lotNum,
        age: now - expectedSale.timestamp,
        success: true
      }));
      return;
    }

    // Reset session safety - AHK calls this after user manually resumes
    if (pathname === '/session-reset') {
      lotSession.safe = true;
      lotSession.exploitReason = '';
      lotSession.exploitMsg = '';
      lotSession.exploitTime = 0;
      console.log('[Session] Safety reset by AHK bot');
      res.end(JSON.stringify({ success: true }));
      return;
    }

    // NEW: Scroller messages endpoint - AHK polls this to confirm price was accepted
    // Returns the latest auction log messages and the last CONFIRMED bid price
    // Real scroller pattern: "ask $950", "ask $980", ">> Last Call...", ">> Going Once..."
    if (pathname === '/scroller-messages') {
      const snapshot = getSnapshotForLot('');
      const messages = snapshot.states?.auctionLog || [];
      // Match "ask $XXX" - this is exactly how LiveAuctioneers logs each accepted bid
      let lastBidPrice = 0;
      let lastBidMsg = '';
      for (let i = messages.length - 1; i >= 0; i--) {
        const msg = messages[i];
        // "ask $950" or "ask $1,200" - the confirmed accepted price in the console
        const askMatch = msg.match(/^ask\s+\$\s*([\d,]+)/i);
        if (askMatch) {
          lastBidPrice = parseInt(askMatch[1].replace(/,/g, ''));
          lastBidMsg = msg;
          break;
        }
      }
      res.end(JSON.stringify({
        messages,
        lastBidPrice,
        lastBidMsg,
        count: messages.length,
        updatedAt: snapshot.updatedAt,
        success: true
      }));
      return;
    }

    if (pathname === '/button-states' || pathname === '/active-state') {
      const selectedLotId = requestUrl.searchParams.get('lotId') || requestUrl.searchParams.get('id') || '';
      const snapshot = getSnapshotForLot(selectedLotId);
      res.end(JSON.stringify({ ...snapshot, success: true }));
      return;
    }

    if (pathname === '/get-pending-commands') {
      // Return but DON'T clear immediately (wait for result report)
      res.end(JSON.stringify({ commands: pendingCommands, success: true }));
      return;
    }

    // Fast flash endpoint — no queue, just returns latest flash request instantly
    if (pathname === '/get-flash') {
      res.end(JSON.stringify(latestFlash));
      return;
    }

    // Latest calc price from calculator extension — bot polls this to compare
    if (pathname === '/calc-price') {
      res.end(JSON.stringify({ ...latestCalcPrice, success: true }));
      return;
    }

    if (pathname === '/set-current-ask-status') {
      const id = requestUrl.searchParams.get('id');
      const result = commandResults.get(id) || { status: 'pending' };
      res.end(JSON.stringify(result));
      return;
    }

    // LITE MODE: check if a LITE AHK script is running via flag file
    if (pathname === '/lite-mode-status') {
      const enabled = fs.existsSync(LITE_MODE_FLAG_FILE);
      res.end(JSON.stringify({ enabled, success: true }));
      return;
    }
  }

  // --- POST ENDPOINTS ---
  let body = '';
  req.on('data', c => body += c);
  req.on('end', () => {
    try {
      const d = JSON.parse(body || '{}');

      if (pathname === '/button-states') {
        const lotId = normalizeLotId(d.lotId);
        if (lotId) {
          latestLotId = lotId;
          // Removed focus restriction since user only uses 1 tab
          activeLotId = lotId;

          lotSnapshots[lotId] = {
            states: d.states || {},
            updatedAt: Date.now()
          };

          if (activeLotId === lotId) {
            console.log(`[Server] Active Lot Updated: ${lotId}`);
            writeLegacyButtonState({ states: d.states || {} });
            fs.writeFileSync(BUTTON_STATES_FILE, JSON.stringify(d.states || {}));
            
            // NEW: PERSISTENT INTERNET PRICE LOGIC
            const internetText = d.states?.internet?.text || '';
            latestInternetText = String(internetText);
            fs.writeFileSync(INTERNET_BID_PRICE_FILE, String(internetText));
            writePriceSnapshot();
          }
        }
      }

      // Lot session events from extension
      if (pathname === '/lot-event') {
        handleLotEvent(d);
        res.end(JSON.stringify({ success: true }));
        return;
      }

      // PRE_SOLD signal from bot - marks sale as expected within 2s window
      if (pathname === '/pre-sold') {
        expectedSale = {
          lotNum: String(d.lotNum || ''),
          timestamp: Date.now()
        };
        console.log(`[PRE_SOLD] Bot authorized sale for Lot ${expectedSale.lotNum}`);
        res.end(JSON.stringify({ success: true, lotNum: expectedSale.lotNum }));
        return;
      }

      // BUTTON FLASH: Instant visual feedback — writes to latestFlash, extension polls /get-flash
      if (pathname === '/flash-button') {
        flashSeq++;
        latestFlash = {
          seq: flashSeq,
          buttonName: d.buttonName || 'unknown',
          duration: d.duration || 400
        };
        console.log(`[Server] Flash: ${d.buttonName}`);
        res.end(JSON.stringify({ success: true, seq: flashSeq }));
        return;
      }

      // CALC PRICE: Calculator extension reports its raw + bid estimate for cross-check
      if (pathname === '/calc-price') {
        const raw = parseFloat(d.rawEstimate) || 0;
        const bid = parseFloat(d.bidEstimate) || 0;
        if (raw > 0 && bid > 0) {
          latestCalcPrice = {
            rawEstimate: raw,
            bidEstimate: bid,
            divisor: parseFloat(d.divisor) || 1.3,
            lotId: String(d.lotId || ''),
            timestamp: Date.now()
          };
          console.log(`[Server] CalcPrice: raw=$${raw} bid=$${bid} lot=${d.lotId}`);
        }
        res.end(JSON.stringify({ success: true }));
        return;
      }

      if (pathname === '/sync-estimate') {
        const rawEstimate = parsePriceValue(d.rawEstimate || d.estimate || d.price);
        const bidEstimate = parsePriceValue(d.bidEstimate);
        const lotId = normalizeLotId(d.lotId);

        lastSyncedEstimate = {
          synced: !!rawEstimate,
          source: d.source || 'calculator',
          rawEstimate,
          bidEstimate,
          divisor: Number(d.divisor || 0),
          lotId,
          timestamp: Date.now()
        };

        if (rawEstimate && lotId) {
          handlePriceUpdate({
            type: 'PRICE_UPDATE',
            source: 'calculator',
            estimate: rawEstimate,
            currentAsk: rawEstimate,
            lotId,
            strategy: d.strategy || 'calculator-http',
            hash: d.hash || 0,
            timestamp: Date.now()
          });
        }

        res.end(JSON.stringify({ success: true, ...lastSyncedEstimate }));
        return;
      }

      if (pathname === '/block-bidding') {
        biddingBlocked = true;
        blockReason = d.reason || 'MANUAL_BLOCK';
        broadcastToClients({ type: 'BIDDING_BLOCKED', reason: blockReason, timestamp: Date.now() });
        res.end(JSON.stringify({ success: true, reason: blockReason }));
        return;
      }

      if (pathname === '/unblock-bidding') {
        biddingBlocked = false;
        blockReason = '';
        broadcastToClients({ type: 'BIDDING_UNBLOCKED', timestamp: Date.now() });
        res.end(JSON.stringify({ success: true }));
        return;
      }

      if (pathname === '/set-current-ask') {
        const cmdId = String(nextCommandId++);
        pendingCommands.push({
          id: cmdId,
          type: 'SET_CURRENT_ASK',
          value: d.value,
          selectOnly: !!d.selectOnly
        });
        res.end(JSON.stringify({ success: true, commandId: cmdId }));
        return;
      }

      if (pathname === '/command-result') {
        if (d.id) {
          if (d.success) {
            // Successfully handled, safe to clear from pending
            pendingCommands = pendingCommands.filter(c => c.id !== d.id);
            commandResults.set(String(d.id), { status: 'done', success: true });
          } else {
            commandResults.set(String(d.id), { status: 'failed', success: false });
          }

          if (commandResults.size > 100) commandResults.clear();
        }
      }

      if (pathname === '/set-active-lot' && d.activeLotId) {
        activeLotId = normalizeLotId(d.activeLotId);
        const activeSnapshot = getSnapshotForLot(activeLotId);
        writeLegacyButtonState(activeSnapshot);
      }

      if (pathname === '/current-ask-price' && d.currentAskPrice) {
        const lotId = normalizeLotId(d.lotId);
        activeLotId = lotId || activeLotId;
        fs.writeFileSync(CURRENT_ASK_PRICE_FILE, String(d.currentAskPrice));
      }

      // BUTTON FLASH: Trigger visual feedback in browser
      if (pathname === '/flash-button') {
        const cmdId = String(nextCommandId++);
        pendingCommands.push({
          id: cmdId,
          type: 'FLASH_BUTTON',
          buttonName: d.buttonName || 'unknown',
          duration: d.duration || 400
        });
        console.log(`[Server] Flash button queued: ${d.buttonName}`);
        res.end(JSON.stringify({ success: true, commandId: cmdId }));
        return;
      }

      if (pathname === '/price' && d.price) {
        const lotId = normalizeLotId(d.lotId);
        activeLotId = lotId || activeLotId;
        latestEstimatePrice = String(d.price);
        fs.writeFileSync(PRICE_FILE, latestEstimatePrice);
        writePriceSnapshot();

        if (d.source === 'calculator' || d.source === 'bot') {
          const price = parsePriceValue(d.price);
          handlePriceUpdate({
            type: 'PRICE_UPDATE',
            source: d.source,
            estimate: price,
            currentAsk: parsePriceValue(d.currentAsk || d.currentAskPrice) || price,
            lotId,
            strategy: d.strategy || 'legacy-http',
            hash: d.hash || 0,
            timestamp: Date.now()
          });
        }
      }

      const activeSnapshot = getSnapshotForLot();
      res.end(JSON.stringify({
        success: true,
        activeLotId: activeSnapshot.activeLotId,
        updatedAt: activeSnapshot.updatedAt
      }));

    } catch (e) {
      res.statusCode = 400;
      res.end(JSON.stringify({ success: false, error: e.message }));
    }
  });

}).listen(PORT);

// ============================================
// WEBSOCKET SERVER (for extensions)
// ============================================

const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
  wsClients.add(ws);
  console.log(`[PriceSync] Client connected. Total: ${wsClients.size}`);
  
  ws.send(JSON.stringify({
    type: 'INITIAL_STATE',
    canonicalPrice,
    biddingBlocked,
    blockReason,
    stats
  }));
  
  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data);
      
      if (msg.type === 'PRICE_UPDATE') {
        handlePriceUpdate(msg);
      } else if (msg.type === 'PING') {
        ws.send(JSON.stringify({ type: 'PONG', timestamp: Date.now() }));
      }
    } catch (e) {
      console.error('[PriceSync] Invalid message:', e.message);
    }
  });
  
  ws.on('close', () => {
    wsClients.delete(ws);
    console.log(`[PriceSync] Client disconnected. Total: ${wsClients.size}`);
  });
  
  ws.on('error', (error) => {
    console.error('[PriceSync] WebSocket error:', error.message);
  });
});

console.log('Server with Price Sync on port 9999');
console.log('HTTP endpoints: /button-states, /can-bid, /stats, /health');
console.log('WebSocket: ws://localhost:9999');
