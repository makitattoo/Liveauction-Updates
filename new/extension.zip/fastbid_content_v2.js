(function() {
  'use strict';
  console.log('[FastBid] Version 2.0 with Price Sync');
  const EXTENSION_SERVER_URL = 'http://localhost:9999';
  
  let lastPrice = '';
  let lastLotId = '';
  let totalUpdates = 0;
  let isMonitoring = true;
  let lastButtonStatesLotId = '';
  let verifiedLotId = '';  // Track verified lot to block bidding until verified
  let verificationInProgress = false;  // Prevent multiple simultaneous verifications
  
  let serverOfflineUntil = 0;
  let serverFailureCount = 0;
  let syncTicks = 0;
  let cachedEstimateEl = null;
  let cachedPriceEl = null;

  // ============================================
  // PRICE SYNC - SHARED READER (SAME AS CALCULATOR)
  // ============================================
  
  function readPriceWithHash() {
    const strategies = [
      () => {
        const el = document.querySelector('.estimate_VL0CI');
        if (!el) return null;
        const text = el.textContent.trim();
        let match = text.match(/Estimate:\s*\$\s*([\d,]+)\s*[-–]\s*[\d,]+/i);
        if (match) return parseInt(match[1].replace(/,/g, ''));
        match = text.match(/Estimate:\s*\$\s*([\d,]+)/i);
        if (match) return parseInt(match[1].replace(/,/g, ''));
        return null;
      },
      () => {
        const el = document.querySelector('input[name="currentAskPrice"], input[aria-label="currentAskPrice"]');
        if (!el || !el.value) return null;
        const cleaned = el.value.replace(/[$,\s]/g, '');
        const num = parseInt(cleaned);
        return (num && num > 0) ? num : null;
      },
      () => {
        const el = document.querySelector('[data-testid*="estimate"], [data-testid*="price"]');
        if (!el) return null;
        const match = el.textContent.match(/\$\s*([\d,]+)/);
        return match ? parseInt(match[1].replace(/,/g, '')) : null;
      },
      () => {
        const el = document.querySelector('[class*="estimate"], [class*="price"]');
        if (!el) return null;
        const text = el.textContent.trim();
        if (text.length > 200) return null;
        const match = text.match(/\$\s*([\d,]+)/);
        return match ? parseInt(match[1].replace(/,/g, '')) : null;
      },
      () => {
        const allEls = document.querySelectorAll('span, div, p, li');
        for (const el of allEls) {
          const txt = el.textContent.trim();
          if (txt.length > 200) continue;
          if (/^estimate\s*:/i.test(txt) && txt.includes('$')) {
            let match = txt.match(/Estimate:\s*\$\s*([\d,]+)\s*[-–]\s*[\d,]+/i);
            if (!match) match = txt.match(/Estimate:\s*\$\s*([\d,]+)/i);
            if (!match) match = txt.match(/\$\s*([\d,]+)/);
            if (match) return parseInt(match[1].replace(/,/g, ''));
          }
        }
        return null;
      }
    ];
    
    for (let i = 0; i < strategies.length; i++) {
      try {
        const result = strategies[i]();
        if (result && result > 0) {
          console.log(`[PriceSync-Bot] Strategy ${i + 1} found: $${result}`);
          return {
            value: result,
            strategy: i + 1,
            hash: generateDOMHash()
          };
        }
      } catch (e) {
        console.log(`[PriceSync-Bot] Strategy ${i + 1} error:`, e.message);
      }
    }
    
    console.log('[PriceSync-Bot] All strategies failed - no price found');
    return null;
  }
  
  function generateDOMHash() {
    const els = document.querySelectorAll('.estimate_VL0CI, input[name="currentAskPrice"], [data-testid*="estimate"]');
    let hashString = '';
    els.forEach(el => {
      hashString += el.textContent + el.className + (el.value || '');
    });
    return simpleHash(hashString);
  }
  
  function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  }
  
  async function tripleReadPrice() {
    const reads = [];
    for (let i = 0; i < 3; i++) {
      const reading = readPriceWithHash();
      if (reading) reads.push(reading);
      if (i < 2) await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    if (reads.length !== 3) return null;
    
    const allMatch = reads.every(r => 
      r.value === reads[0].value && 
      r.strategy === reads[0].strategy
    );
    
    if (!allMatch) {
      console.log('[PriceSync-Bot] Triple read mismatch:', reads);
      return null;
    }
    
    return reads[0];
  }

  function getPriceSyncLotId() {
    let auctionId = '0';
    const urlMatches = window.location.href.match(/\/(\d{5,10})(?:\/|\?|#|$)/)
                    || window.location.href.match(/id=(\d{5,10})/);
    if (urlMatches) {
      auctionId = urlMatches[1];
    }

    if (auctionId === '0') {
      const bodyId = document.querySelector('[data-auction-id], [id*="auction-id"]');
      if (bodyId) {
        const extracted = bodyId.getAttribute('data-auction-id')
          || ((bodyId.innerText || '').match(/\d+/) || [])[0];
        if (extracted) auctionId = extracted;
      }
    }

    let lotNumber = '-';
    const input = document.querySelector('input[name="lotNumber"], input[aria-label="lotNumber"], .lot-number-input');
    if (input && input.value) {
      lotNumber = input.value.trim();
    } else {
      const label = document.querySelector('.lot-label, [class*="lotNumber"], [class*="lot-id"], h1[class*="LotNumber"]');
      if (label && label.textContent) {
        const m = label.textContent.match(/Lot\s*#?([A-Z0-9-]+)/i);
        lotNumber = m ? m[1] : label.textContent.trim().slice(0, 10);
      }
    }

    if (lotNumber === '-' || /^lot\s*:?#?$/i.test(lotNumber)) {
      const lotFromPath = window.location.pathname.match(/\/([A-Z0-9-]+)$/i);
      if (lotFromPath) lotNumber = lotFromPath[1];
    }

    return auctionId + '_' + lotNumber;
  }
  
  // ============================================
  // WEBSOCKET CONNECTION TO SERVER
  // ============================================
  
  let ws = null;
  let wsReconnectTimer = null;
  
  function connectWebSocket() {
    if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) {
      return;
    }
    
    ws = new WebSocket('ws://localhost:9999');
    
    ws.onopen = () => {
      console.log('[PriceSync-Bot] Connected to server');
      sendPriceUpdate();
    };
    
    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'INITIAL_STATE' || msg.type === 'PRICE_UPDATE') {
          console.log('[PriceSync-Bot] Server state:', msg.biddingBlocked ? 'BLOCKED' : 'OK');
        }
      } catch (e) {
        console.error('[PriceSync-Bot] Message error:', e);
      }
    };
    
    ws.onerror = (error) => {
      console.error('[PriceSync-Bot] WebSocket error:', error);
    };
    
    ws.onclose = () => {
      console.log('[PriceSync-Bot] Disconnected, reconnecting in 3s...');
      if (wsReconnectTimer) clearTimeout(wsReconnectTimer);
      wsReconnectTimer = setTimeout(connectWebSocket, 3000);
    };
  }
  
  async function sendPriceUpdate() {
    const priceData = await tripleReadPrice();
    
    // If triple read fails, try single read as fallback
    if (!priceData) {
      console.log('[PriceSync-Bot] Triple read failed, skipping update');
      return;
    }
    
    const currentAskEl = document.querySelector('input[name="currentAskPrice"]');
    const currentAsk = currentAskEl ? parseInt(currentAskEl.value.replace(/[$,\s]/g, '')) || 0 : 0;
    
    // Try multiple ways to get lot ID
    let lotId = getPriceSyncLotId() || '';
    
    const message = {
      type: 'PRICE_UPDATE',
      source: 'bot',
      estimate: priceData.value,
      currentAsk: currentAsk,
      lotId: lotId,
      strategy: priceData.strategy,
      hash: priceData.hash,
      timestamp: Date.now()
    };
    
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
      console.log('[PriceSync-Bot] Sent:', message);
    } else {
      console.log('[PriceSync-Bot] WebSocket not open, skipping update');
    }
  }
  
  // Start WebSocket connection
  connectWebSocket();
  
  // Send price updates every 500ms
  setInterval(sendPriceUpdate, 500);

  // ============================================
  // EXISTING BOT CODE
  // ============================================

  async function safeFetch(url, options) {
    if (Date.now() < serverOfflineUntil) return null;
    
    try {
      const resp = await fetch(url, options);
      // Reset only if we actually got a response (not 404 or something, but connection worked)
      serverFailureCount = 0; 
      return resp;
    } catch (e) {
      serverFailureCount++;
      if (serverFailureCount > 3) {
        console.warn('[FastBid] Server seems offline. Backing off for 5 seconds...');
        serverOfflineUntil = Date.now() + 5000;
      }
      return null;
    }
  }

  console.log('[FastBid] Monitor Script Initializing...');

  // Force a layout reflow so getBoundingClientRect() returns committed positions.
  // This is critical after Chrome is restored from background/minimized state —
  // without it, coords can be stale from the last painted frame.
  function forceReflow() {
    void document.body.offsetHeight;
  }

  // Track page state to detect when reflow is actually needed
  let lastPageWidth = window.innerWidth;
  let lastPageHeight = window.innerHeight;
  let lastDevicePixelRatio = window.devicePixelRatio || 1;

  function needsPageRecalc() {
    // Only reflow if the page size or zoom changed
    const currentWidth = window.innerWidth;
    const currentHeight = window.innerHeight;
    const currentDPR = window.devicePixelRatio || 1;
    
    if (currentWidth !== lastPageWidth || currentHeight !== lastPageHeight || currentDPR !== lastDevicePixelRatio) {
      lastPageWidth = currentWidth;
      lastPageHeight = currentHeight;
      lastDevicePixelRatio = currentDPR;
      return true;
    }
    return false;
  }

  function getElementInfo(el) {
    if (!el) return { exists: false, enabled: false };
    
    // Only force reflow if page dimensions changed (resize/zoom)
    if (needsPageRecalc()) {
      forceReflow();
    }
    
    const r = el.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    return {
      exists: true,
      enabled: !el.disabled && el.style.display !== 'none' && el.style.visibility !== 'hidden',
      centerXDevice: Math.round((r.left + r.width / 2) * dpr),
      centerYDevice: Math.round((r.top + r.height / 2) * dpr),
      centerX: Math.round(r.left + r.width / 2),
      centerY: Math.round(r.top + r.height / 2)
    };
  }

  function findBtn(keywords) {
    const btns = document.querySelectorAll('button');
    for (const b of btns) {
      const text = (b.textContent || '').toLowerCase();
      for (const k of keywords) {
        if (text.includes(k.toLowerCase())) return b;
      }
    }
    return null;
  }

  function normalizeButtonText(value) {
    return (value || '').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function findBtnExact(labels) {
    const wanted = labels.map(normalizeButtonText);
    const btns = document.querySelectorAll('button');
    for (const b of btns) {
      if (wanted.includes(normalizeButtonText(b.textContent))) return b;
    }
    return null;
  }

  function findBtnsExact(labels) {
    const wanted = labels.map(normalizeButtonText);
    return Array.from(document.querySelectorAll('button'))
      .filter(b => wanted.includes(normalizeButtonText(b.textContent)));
  }

  function installUnsoldClickBlocker() {
    if (window.__fastbidUnsoldClickBlockerInstalled) return;
    window.__fastbidUnsoldClickBlockerInstalled = true;

    const blockIfUnsold = (event) => {
      const btn = event.target && event.target.closest ? event.target.closest('button') : null;
      if (!btn || normalizeButtonText(btn.textContent) !== 'unsold') return;
      event.preventDefault();
      event.stopImmediatePropagation();
    };

    ['pointerdown', 'mousedown', 'mouseup', 'click'].forEach(type => {
      document.addEventListener(type, blockIfUnsold, true);
    });
  }

  function setUnsoldGuard() {
    installUnsoldClickBlocker();
    for (const btn of document.querySelectorAll('button')) {
      const text = normalizeButtonText(btn.textContent);

      if (text === 'unsold') {
        btn.dataset.fastbidUnsoldGuard = '1';
        btn.setAttribute('aria-disabled', 'true');
      } else if (btn.dataset.fastbidUnsoldGuard) {
        btn.removeAttribute('aria-disabled');
        delete btn.dataset.fastbidUnsoldGuard;
      }
    }
  }

  /**
   * @param {HTMLButtonElement|null} btn
   * @param {ReturnType<typeof getElementInfo>} base
   */
  function buildInternetState(btn, base) {
    if (!btn || !base.exists) {
      return {
        exists: false,
        enabled: false,
        text: '',
        hasPriceInLabel: false,
        ready: false,
        readyReason: 'missing'
      };
    }

    const text = (btn.textContent || '').trim().slice(0, 120);
    const hasPriceInLabel = /\$\s*[\d,]+/.test(text);
    const ready = Boolean(base.enabled);

    return {
      ...base,
      text,
      hasPriceInLabel,
      ready,
      readyReason: ready ? 'enabled_with_price' : (base.enabled ? 'enabled_no_price' : 'disabled')
    };
  }

  async function sync() {
    if (!isMonitoring) return;
    if (Date.now() < serverOfflineUntil) return;
    
    syncTicks++;

    // --- LOT ID MONITOR (Composite Signature) ---
    function findLotId() {
        // 1. Get the Auction ID (The 'Switching Sign' from URL or Page)
        let auctionId = '0';
        
        // Strategy A: Direct URL Hunt (Looking for any 5-10 digit identification number)
        const urlMatches = window.location.href.match(/\/(\d{5,10})(?:\/|\?|#|$)/) 
                        || window.location.href.match(/id=(\d{5,10})/);
        if (urlMatches) {
            auctionId = urlMatches[1];
        }

        // Strategy B: Page Source Hunt (If URL is masked)
        if (auctionId === '0') {
            const bodyId = document.querySelector('[data-auction-id], [id*="auction-id"]');
            if (bodyId) auctionId = bodyId.getAttribute('data-auction-id') || bodyId.innerText.match(/\d+/)[0];
        }

        // 2. Get the Lot Number (The 'Active Lot' from UI)
        let lotNumber = '-';
        const input = document.querySelector('input[name="lotNumber"], input[aria-label="lotNumber"], .lot-number-input');
        if (input && input.value) {
            lotNumber = input.value.trim();
        } else {
            const label = document.querySelector('.lot-label, [class*="lotNumber"], [class*="lot-id"], h1[class*="LotNumber"]');
            if (label && label.textContent) {
                const m = label.textContent.match(/Lot\s*#?([A-Z0-9-]+)/i);
                lotNumber = m ? m[1] : label.textContent.trim().slice(0, 10);
            }
        }

        // 3. Combine them: SwitchingSign_ActiveLot
        return auctionId + '_' + lotNumber;
    }

    let lotId = findLotId() || lastLotId || '-';
    if (lotId && lotId !== '-' && lotId !== lastLotId) {
        lastLotId = lotId;
        verifiedLotId = '';  // Clear verified status - new lot needs verification
        // Trigger triple verification for this new lot (non-blocking, will take ~3 seconds)
        tripleVerifyEstimateForNewLot(lotId);
    }

    // --- 1. ESTIMATE MONITOR ---
    let estText = '';

    // Strategy 1: Known CSS class
    const estEl = document.querySelector('.estimate_VL0CI');
    if (estEl) estText = estEl.textContent.trim();

    // Strategy 2: Any element with data-testid containing "estimate"
    if (!estText) {
        const estAttr = document.querySelector('[data-testid*="estimate"], [class*="estimate"]');
        if (estAttr) estText = estAttr.textContent.trim();
    }

    // Strategy 3: Full text scan for "Estimate:" label on the page
    if (!estText) {
        if (cachedEstimateEl && cachedEstimateEl.isConnected) {
            const txt = cachedEstimateEl.textContent.trim();
            if (/^estimate\s*:/i.test(txt) && txt.includes('$')) {
                estText = txt;
            } else {
                cachedEstimateEl = null;
            }
        }
        
        if (!estText && (syncTicks % 20 === 0)) { // Throttle to 500ms
            const allEls = document.querySelectorAll('span, div, p, li');
            for (const el of allEls) {
                const txt = el.textContent.trim();
                if (/^estimate\s*:/i.test(txt) && txt.includes('$')) {
                    estText = txt;
                    cachedEstimateEl = el;
                    break;
                }
            }
        }
    }

    if (estText) {
        estText = estText.replace(/^estimate\s*:\s*/i, '').trim();
        if (estText.includes('$')) {
            safeFetch(`${EXTENSION_SERVER_URL}/price`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    price: estText, 
                    lotId: lotId,
                    focused: document.hasFocus() && document.visibilityState === 'visible'
                })
            });
        }
    }

    // --- 2. CURRENT PRICE MONITOR ---
    let currentPrice = '';
    
    // Check the primary LiveAuctioneers bid input
    const bidInput = document.querySelector('input[name="currentAskPrice"], input[aria-label="currentAskPrice"]');
    if (bidInput && bidInput.value && bidInput.value !== '$0') {
        currentPrice = bidInput.value.replace(/[$,\s]/g, '');
    }

    // Fallback: Search page for currency patterns
    if (!currentPrice || currentPrice === '0') {
      if (cachedPriceEl && cachedPriceEl.isConnected) {
          const val = cachedPriceEl.textContent.trim();
          if (val.includes('$') && val.length < 15) {
              const clean = val.replace(/[$,\s]/g, '');
              if (clean && clean !== '0') { 
                  currentPrice = clean; 
              } else {
                  cachedPriceEl = null;
              }
          } else {
              cachedPriceEl = null;
          }
      }

      if ((!currentPrice || currentPrice === '0') && (syncTicks % 20 === 0)) {
          const allDivs = document.querySelectorAll('div, span, b, p');
          for (const el of allDivs) {
            const val = el.textContent.trim();
            if (val.includes('$') && val.length < 15) {
              if (/current|bid|ask|price/i.test(el.parentElement.textContent || '')) {
                const clean = val.replace(/[$,\s]/g, '');
                if (clean && clean !== '0') { 
                    currentPrice = clean; 
                    cachedPriceEl = el;
                    break; 
                }
              }
            }
          }
      }
    }

    if (currentPrice && currentPrice !== '0') {
        // ALWAYS update storage and send to server to keep AHK fresh
        lastPrice = currentPrice;
        lastLotId = lotId;
        totalUpdates++;
        

        safeFetch(`${EXTENSION_SERVER_URL}/current-ask-price`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            currentAskPrice: currentPrice, 
            lotId: lotId,
            focused: document.hasFocus() && document.visibilityState === 'visible'
          })
        });
    }

    // --- 3. BUTTON MONITOR ---
    if (lotId !== lastButtonStatesLotId) {
      lastButtonStatesLotId = lotId;
    }

      let progressPct = '';
      let progressText = '';
      const progressEl = document.querySelector('[class*="progress_"]');
      if (progressEl) {
        const divs = progressEl.querySelectorAll('div');
        for (let i = 0; i < divs.length; i++) {
          let t = divs[i].textContent || '';
          if (t.includes('%')) progressPct = t.trim();
          if (t.toLowerCase().includes('remaining')) progressText = t.trim();
        }
      }

      // --- AUCTION LOG MONITOR ---
      let lotIsClosed = false;
      let lotIsLastCall = false;
      let lotIsFairWarning = false;
      let hasErrorMissive = false;
      
      let messages = [];
      let currentLotMessages = [];
      const logContainer = document.querySelector('[class*="auctionInformation"] [class*="scroller"]');
      if (logContainer) {
        const rows = logContainer.querySelectorAll('[class*="row"]');
        messages = Array.from(rows).map(row => row.textContent.trim());
        
        // Check for error_CAQKD class (Failed to send missive)
        hasErrorMissive = Array.from(rows).some(row => 
          row.className.includes('error_CAQKD') || row.textContent.includes('Failed to send missive')
        );
        
        // Find messages for the current lot (after last "opened")
        let lastOpenedIndex = -1;
        for (let i = messages.length - 1; i >= 0; i--) {
          if (messages[i].includes('opened')) {
            lastOpenedIndex = i;
            break;
          }
        }
        
        if (lastOpenedIndex !== -1) {
          currentLotMessages = messages.slice(lastOpenedIndex);
        } else {
          currentLotMessages = messages; // Fallback
        }
        
        // Extract lot number from lotId (e.g., "12345_946A" -> "946A")
        const lotNumMatch = lotId.match(/_([A-Z0-9-]+)$/);
        const currentLotNum = lotNumMatch ? lotNumMatch[1] : '';
        
        if (currentLotNum) {
          // Check if current lot is closed or passed
          lotIsClosed = currentLotMessages.some(msg => msg.includes(`Lot ${currentLotNum} closed`) || msg.includes(`Lot ${currentLotNum} passed`));
        }
        
        lotIsLastCall = currentLotMessages.some(msg => msg.includes('Last Call') || msg.includes('Last call'));
        lotIsFairWarning = currentLotMessages.some(msg => msg.includes('Fair warning') || msg.includes('Going Once') || msg.includes('going once'));
        
        // Reset log if closed (User request)
        if (lotIsClosed) {
          currentLotMessages = [];
        }

        // ============================================
        // LOT SESSION INTEGRITY + EXPLOIT DETECTION
        // ============================================
        trackLotSessionEvents(messages, currentLotMessages);
      }

      setUnsoldGuard();
      const internet = findBtn(['Internet']);
      const soldBtn = findBtnExact(['Sold']);
      const internetBase = getElementInfo(internet);
      const states = {
        progress: { pct: progressPct, text: progressText },
        internet: buildInternetState(internet, internetBase),
        currentask: getElementInfo(bidInput),
        competing: getElementInfo(findBtn(['Competing Bid', 'Competing'])),
        next: getElementInfo(findBtn(['Next Lot'])),
        sold: getElementInfo(soldBtn),
        pass: getElementInfo(findBtn(['Pass'])),
        fair: getElementInfo(findBtn(['Fair Warning', 'Fair'])),
        going: getElementInfo(findBtn(['Going Once', 'Going Once...Going Twice', 'Going', 'Once', 'Twice'])),
        lastcall: getElementInfo(findBtn(['Last Call'])),
        sendmessage: getElementInfo(findBtn(['Send Message'])),
        lotIsClosed: lotIsClosed,
        lotIsLastCall: lotIsLastCall,
        lotIsFairWarning: lotIsFairWarning,
        hasErrorMissive: hasErrorMissive,
        auctionLog: currentLotMessages
    };

    safeFetch(`${EXTENSION_SERVER_URL}/button-states`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        states, 
        lotId,
        focused: document.hasFocus() && document.visibilityState === 'visible'
      })
    });
  }

  // ============================================
  // LOT SESSION TRACKING
  // Sends events to server when lot transitions happen
  // or when a suspicious action is detected
  // ============================================

  let lastSeenMessages = [];        // full scroller snapshot from last sync
  let sessionTrackedLot = '';       // lot number currently being tracked

  function trackLotSessionEvents(allMessages, currentLotMessages) {
    // Find the newest messages we haven't seen yet
    const newMessages = allMessages.slice(lastSeenMessages.length);
    if (newMessages.length === 0) return;
    lastSeenMessages = allMessages.slice(); // update snapshot

    // If sessionTrackedLot is empty (extension loaded mid-auction),
    // scan ALL messages backwards to find the most recent "opened" line
    // so we don't miss exploit detection on the current lot
    if (!sessionTrackedLot) {
      for (let i = allMessages.length - 1; i >= 0; i--) {
        const m = allMessages[i].trim().match(/^Lot\s+([A-Z0-9-]+)\s+opened/i);
        if (m) {
          sessionTrackedLot = m[1];
          console.log('[LotSession] Recovered session from history: Lot ' + sessionTrackedLot);
          break;
        }
      }
    }

    for (const msg of newMessages) {
      const trimmed = msg.trim();
      if (!trimmed) continue;

      console.log('[LotSession] New message: ' + trimmed);

      // --- LOT OPENED → new session marker ---
      const openedMatch = trimmed.match(/^Lot\s+([A-Z0-9-]+)\s+opened/i);
      if (openedMatch) {
        const lotNum = openedMatch[1];
        sessionTrackedLot = lotNum;
        console.log('[LotSession] LOT OPENED: ' + lotNum);
        sendLotEvent('LOT_OPENED', lotNum, trimmed, null);
        continue;
      }

      // Analyse all events regardless — don't skip if sessionTrackedLot is empty
      // Use lotNum from message itself as fallback
      const lotNumFallback = sessionTrackedLot || '?';

      // --- LOT SOLD → check if bot-authorised via PRE_SOLD signal ---
      // Pattern from real scroller: "Lot 816R sold for $425 to Competing Bid."
      //                             "Lot 816R sold for $425."  ← manual exploit
      // Even "to Competing Bid" can be manual if YOU clicked Sold while bot had active bid
      const soldMatch = trimmed.match(/^Lot\s+([A-Z0-9-]+)\s+sold\s+for\s+\$?([\d,]+)(.*)/i);
      if (soldMatch) {
        const lotNum  = soldMatch[1];
        const price   = parseInt(soldMatch[2].replace(/,/g, ''));
        
        // Check server: did bot send PRE_SOLD signal before clicking Sold?
        fetch('http://localhost:9999/check-pre-sold?lotNum=' + encodeURIComponent(lotNum))
          .then(r => r.json())
          .then(data => {
            if (data.expected) {
              console.log('[LotSession] LOT SOLD OK: Lot ' + lotNum + ' $' + price + ' (bot-authorized, age=' + data.age + 'ms)');
              sendLotEvent('LOT_SOLD_OK', lotNum, trimmed, price);
            } else {
              console.error('[LotSession] EXPLOIT: Manual sale of Lot ' + lotNum + ' for $' + price + ' (no PRE_SOLD signal)');
              sendLotEvent('EXPLOIT_MANUAL_SALE', lotNum, trimmed, price);
            }
          })
          .catch(err => {
            console.error('[LotSession] PRE_SOLD check failed:', err);
            // Fallback: treat as exploit to be safe
            sendLotEvent('EXPLOIT_MANUAL_SALE', lotNum, trimmed, price);
          });
        continue;
      }

      // --- LOT PASSED → always suspicious ---
      const passedMatch = trimmed.match(/^Lot\s+([A-Z0-9-]+)\s+passed/i);
      if (passedMatch) {
        console.error('[LotSession] EXPLOIT: Manual pass of Lot ' + passedMatch[1]);
        sendLotEvent('EXPLOIT_MANUAL_PASS', passedMatch[1], trimmed, null);
        continue;
      }

      // --- LOT CLOSED → normal ---
      const closedMatch = trimmed.match(/^Lot\s+([A-Z0-9-]+)\s+closed/i);
      if (closedMatch) {
        sendLotEvent('LOT_CLOSED', closedMatch[1], trimmed, null);
        continue;
      }

      // --- Everything else: ask prices, Last Call, Going Once etc. ---
      sendLotEvent('LOG', lotNumFallback, trimmed, null);
    }
  }

  function sendLotEvent(type, lotNum, message, price) {
    safeFetch(`${EXTENSION_SERVER_URL}/lot-event`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type,
        lotNum,
        message,
        price,
        timestamp: Date.now()
      })
    });
  }

  // Lock flag - prevents two SET_CURRENT_ASK commands from running simultaneously
  let injectionInProgress = false;

  async function typePriceNumberByNumber(inputElement, priceValue) {
    if (!inputElement) return false;

    // If another injection is already running, wait for it to finish (max 2s)
    const lockDeadline = Date.now() + 2000;
    while (injectionInProgress) {
      if (Date.now() > lockDeadline) {
        console.warn('[FastBid] Injection lock timeout - forcing unlock');
        injectionInProgress = false;
        break;
      }
      await new Promise(resolve => setTimeout(resolve, 30));
    }

    injectionInProgress = true;
    try {
      const priceStr = String(priceValue).replace(/,/g, '').trim();
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;

      // STEP 1: Clear the field using native setter (bypasses React's synthetic control)
      inputElement.focus();
      inputElement.select();
      nativeInputValueSetter.call(inputElement, '');
      inputElement.dispatchEvent(new Event('input', { bubbles: true }));
      await new Promise(resolve => setTimeout(resolve, 80));

      // STEP 2: Set full value at once using native setter - no digit-by-digit
      // This avoids the race condition where large numbers (5+ digits × 150ms = 750ms+)
      // overlap with a second AHK command arriving before typing finishes
      nativeInputValueSetter.call(inputElement, priceStr);
      inputElement.dispatchEvent(new Event('input',  { bubbles: true }));
      inputElement.dispatchEvent(new Event('change', { bubbles: true }));
      await new Promise(resolve => setTimeout(resolve, 80));

      // STEP 3: Verify the field actually shows what we set
      const finalVal = inputElement.value.replace(/[$,\s]/g, '');
      if (finalVal !== priceStr) {
        // React may have overridden our value - try once more with select-all + type
        inputElement.focus();
        inputElement.select();
        nativeInputValueSetter.call(inputElement, priceStr);
        inputElement.dispatchEvent(new Event('input',  { bubbles: true }));
        inputElement.dispatchEvent(new Event('change', { bubbles: true }));
        await new Promise(resolve => setTimeout(resolve, 80));

        const retryVal = inputElement.value.replace(/[$,\s]/g, '');
        if (retryVal !== priceStr) {
          console.error('[FastBid] Injection failed after retry. Expected $' + priceStr + ' got $' + retryVal);
          injectionInProgress = false;
          return false;
        }
      }

      console.log('[FastBid] Injection OK: $' + priceStr);
      injectionInProgress = false;
      return true;
    } catch (e) {
      console.error('[FastBid] Injection error:', e.message);
      injectionInProgress = false;
      return false;
    }
  }

async function handlePendingCommands() {
    if (Date.now() < serverOfflineUntil) return;
    try {
      const isFocused = document.hasFocus() && document.visibilityState === 'visible';
      const resp = await safeFetch(`${EXTENSION_SERVER_URL}/get-pending-commands`);
      if (!resp) return;
      const data = await resp.json();
      
      if (data.success && data.commands && data.commands.length > 0) {
        for (const cmd of data.commands) {
          // IMPORTANT: Only the focused tab handles commands to avoid conflicts
          if (!isFocused) continue; 

          // NEW: Manual Override - If user is actively typing/focusing the element, don't hijack it
          const activeEl = document.activeElement;
          const isUserInteracting = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA');

          let success = false;
          if (cmd.type === 'SET_CURRENT_ASK') {
            const el = document.querySelector('input[name="currentAskPrice"], input[aria-label="currentAskPrice"]');
            if (el) {
              // Only inject if the user isn't currently typing in THIS specific element
              if (activeEl !== el) {
                el.focus();
                if (cmd.selectOnly) {
                  el.select();
                  success = true;
                } else {
                  // NEW: Type price number-by-number instead of instant set
                  success = await typePriceNumberByNumber(el, cmd.value);
                }
              } else {
                // User is in the box! Skip this update but report "success" so it clears from queue
                // or we can wait. Let's report success to clear the stuck command.
                success = true; 
              }
            }
          }
          
          // Report result back to server
          safeFetch(`${EXTENSION_SERVER_URL}/command-result`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: cmd.id, success })
          });
        }
      }
    } catch (e) {}
  }

  // Listen for messages including status requests and toggle commands
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'GET_STATUS') {
      sendResponse({
        lastPrice,
        lastLotId,
        totalUpdates,
        isMonitoring
      });
    } else if (request.type === 'TOGGLE_MONITOR') {
      isMonitoring = request.enabled;
      console.log('[FastBid] Monitoring ' + (isMonitoring ? 'ENABLED' : 'DISABLED'));
      sendResponse({ success: true, isMonitoring });
    }
  });

  console.log('[FastBid] Chrome Monitor Active - Auto-Backoff Engaged.');
  setInterval(() => {
    sync();
    handlePendingCommands();
  }, 100);

  // ==========================================
  // EXPLOIT DETECTION MODULE - NEW
  // Monitors scroller for price/lot anomalies
  // ==========================================

  let currentLot = null;
  let currentEstimate = null;
  let monitoringActive = false;
  let lastMessageCount = 0;

  function getScrollerMessages() {
    const logContainer = document.querySelector('[class*="auctionInformation"] [class*="scroller"]');
    if (!logContainer) return [];
    
    const rows = logContainer.querySelectorAll('[class*="row"]');
    return Array.from(rows).map(row => row.textContent.trim());
  }

  function validatePriceProgression(messages) {
    const prices = messages
      .filter(m => m.toLowerCase().includes('ask $'))
      .map(m => {
        const match = m.match(/\$?([\d,]+)/);
        return match ? parseInt(match[1].replace(/,/g, '')) : 0;
      });
    
    // Prices never go backwards
    for (let i = 1; i < prices.length; i++) {
      if (prices[i] < prices[i-1]) {
        return {
          valid: false,
          reason: `Price went backwards: $${prices[i-1]} → $${prices[i]}`
        };
      }
    }
    
    // Price doesn't jump more than 100%
    for (let i = 1; i < prices.length; i++) {
      if (prices[i] > prices[i-1] * 2) {
        return {
          valid: false,
          reason: `Price jumped >100%: $${prices[i-1]} → $${prices[i]}`
        };
      }
    }
    
    return { valid: true };
  }

  function validateLotClosure(messages, expectedLot) {
    const closureMessages = messages.filter(m => 
      m.toLowerCase().includes('closed')
    );
    
    if (closureMessages.length === 0) {
      return { valid: true, reason: 'No closure yet' };
    }
    
    const lastClosure = closureMessages[closureMessages.length - 1];
    const match = lastClosure.match(/Lot\s+([A-Z0-9]+)\s+closed/i);
    
    if (!match) {
      return { valid: false, reason: `Invalid closure message: ${lastClosure}` };
    }
    
    const closedLot = match[1];
    
    if (closedLot !== expectedLot) {
      return {
        valid: false,
        reason: `Wrong lot closed! Expected ${expectedLot}, got ${closedLot}`
      };
    }
    
    return { valid: true, reason: `Lot ${closedLot} closed correctly` };
  }

  function validateFairWarning(messages) {
    const fairMessages = messages.filter(m => 
      m.includes('Going Once') || m.includes('Last Call') || m.includes('Fair')
    );
    
    const askMessages = messages.filter(m => m.includes('ask'));
    
    if (fairMessages.length > 0 && askMessages.length === 0) {
      return {
        valid: false,
        reason: 'Fair warning without any bids'
      };
    }
    
    return { valid: true };
  }

  function checkPattern() {
    if (!monitoringActive) return;
    
    const messages = getScrollerMessages();
    
    if (messages.length === lastMessageCount) {
      return;
    }
    
    console.log(`[FastBid] New messages (${lastMessageCount} → ${messages.length})`);
    lastMessageCount = messages.length;
    
    // Validate price progression
    const priceCheck = validatePriceProgression(messages);
    if (!priceCheck.valid) {
      console.error(`[FastBid] ❌ PRICE ANOMALY: ${priceCheck.reason}`);
      triggerExploit('PRICE_ANOMALY', priceCheck.reason, messages);
      return;
    }
    
    // Validate fair warning sequence
    const fairCheck = validateFairWarning(messages);
    if (!fairCheck.valid) {
      console.error(`[FastBid] ❌ FAIR WARNING ANOMALY: ${fairCheck.reason}`);
      triggerExploit('FAIR_ANOMALY', fairCheck.reason, messages);
      return;
    }
    
    // Validate lot closure
    if (currentLot) {
      const closureCheck = validateLotClosure(messages, currentLot);
      if (!closureCheck.valid && messages.some(m => m.includes('closed'))) {
        console.error(`[FastBid] ❌ CLOSURE ANOMALY: ${closureCheck.reason}`);
        triggerExploit('CLOSURE_ANOMALY', closureCheck.reason, messages);
        return;
      }
    }
    
    console.log('[FastBid] ✅ Pattern validation passed');
  }

  function triggerExploit(type, reason, messages) {
    console.error(`[FastBid] 🚨 EXPLOIT DETECTED: ${type}`);
    console.error(`[FastBid] Reason: ${reason}`);
    
    fetch(`${EXTENSION_SERVER_URL}/exploit-alert`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        exploitType: type,
        reason: reason,
        currentLot: currentLot,
        messages: messages.slice(-20),
        timestamp: Date.now(),
        url: window.location.href
      })
    }).then(() => {
      console.log('[FastBid] Alert sent to server');
      // REMOVED: Auto-reload on exploit detection
    }).catch(err => {
      console.error('[FastBid] Failed to send alert:', err);
      // REMOVED: Auto-reload on error
    });
  }

  function updateLotInfo() {
    const messages = getScrollerMessages();
    
    const lotMatch = messages.find(m => m.includes('opened'));
    
    if (lotMatch) {
      const match = lotMatch.match(/Lot\s+([A-Z0-9]+)/);
      if (match) {
        currentLot = match[1];
        console.log(`[FastBid] Current Lot: ${currentLot}`);
      }
    }
  }

  function startMonitoring() {
    if (monitoringActive) return;
    
    monitoringActive = true;
    console.log('[FastBid] Starting exploit detection monitoring...');
    
    const logContainer = document.querySelector('[class*="auctionInformation"] [class*="scroller"]');
    
    if (logContainer) {
      const observer = new MutationObserver(() => {
        updateLotInfo();
        checkPattern();
      });
      
      observer.observe(logContainer, {
        childList: true,
        subtree: true,
        characterData: true
      });
      
      console.log('[FastBid] Scroller mutation observer started');
    }
    
    // Also check every 2 seconds as fallback
    setInterval(() => {
      if (monitoringActive) {
        checkPattern();
      }
    }, 2000);
  }

  // Start monitoring when page loads
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startMonitoring);
  } else {
    startMonitoring();
  }

  console.log('[FastBid] Exploit Detection Module Ready');

  // === ZERO-TOLERANCE ESTIMATE SYNC VERIFICATION ===
  // Validate bot's estimate matches calculator extension's estimate
  // Both read same website DOM, must calculate identical results
  
  async function getSyncedEstimateFromServer() {
    try {
      const response = await safeFetch(`${EXTENSION_SERVER_URL}/sync-estimate`);
      if (!response || !response.ok) return null;
      
      const data = await response.json();
      return {
        bidEstimate: data.bidEstimate || 0,
        rawEstimate: data.rawEstimate || 0,
        divisor: data.divisor || 1.3,
        timestamp: data.timestamp || 0
      };
    } catch (e) {
      console.warn('[FastBid] Cannot get synced estimate:', e.message);
      return null;
    }
  }
  
  async function verifySyncedEstimate() {
    // Get calculator's estimate from server
    const syncData = await getSyncedEstimateFromServer();
    if (!syncData || syncData.bidEstimate <= 0) {
      console.warn('[FastBid] Synced estimate not available');
      return { verified: false, reason: 'calculator_offline' };
    }
    
    // Get bot's estimate directly from website DOM using multi-strategy search
    let botRawEstimate = 0;
    let foundVia = '';
    
    // Strategy 1: Try the known class with range support
    let estEl = document.querySelector('.estimate_VL0CI');
    if (estEl) {
      const estText = (estEl.textContent || '').trim();
      // For range format: "Estimate: $ 299 - 388", capture the LOW estimate (299)
      let match = estText.match(/Estimate:\s*\$\s*([\d,]+)\s*[-–]\s*[\d,]+/i);
      if (match) {
        botRawEstimate = parseFloat(match[1].replace(/,/g, ''));
        foundVia = 'class:.estimate_VL0CI (range)';
      } else {
        // Fallback for single estimate
        match = estText.match(/Estimate:\s*\$\s*([\d,]+)/i);
        if (match) {
          botRawEstimate = parseFloat(match[1].replace(/,/g, ''));
          foundVia = 'class:.estimate_VL0CI (single)';
        }
      }
    }
    
    // Strategy 2: Search for "Estimate:" text
    if (!botRawEstimate) {
      const allEls = document.querySelectorAll('*');
      for (const el of allEls) {
        const text = (el.textContent || '').trim();
        if (text.length < 200 && text.includes('Estimate:') && text.includes('$')) {
          // Try range format first (capture first number)
          let match = text.match(/Estimate:\s*\$\s*([\d,]+)\s*[-–]\s*[\d,]+/i);
          if (!match) {
            match = text.match(/Estimate:\s*\$\s*([\d,]+)/i);
          }
          if (!match) {
            match = text.match(/\$\s*([\d,]+)/);
          }
          if (match) {
            botRawEstimate = parseFloat(match[1].replace(/,/g, ''));
            foundVia = 'text:contains("Estimate:")';
            break;
          }
        }
      }
    }
    
    // Strategy 3: Search for any price element
    if (!botRawEstimate) {
      const pricePatterns = document.querySelectorAll('[class*="price"], [class*="estimate"], [data-testid*="price"], [data-testid*="estimate"]');
      for (const el of pricePatterns) {
        const text = (el.textContent || '').trim();
        if (text.includes('$') && /\d+/.test(text) && text.length < 200) {
          const match = text.match(/\$\s*([\d,]+)/);
          if (match) {
            botRawEstimate = parseFloat(match[1].replace(/,/g, ''));
            foundVia = 'selector:[price/estimate]';
            break;
          }
        }
      }
    }
    
    if (botRawEstimate <= 0) {
      console.warn('[FastBid] Bot estimate not found on page');
      return { verified: false, reason: 'estimate_not_found' };
    }
    
    // Use the ACTUAL divisor from calculator (not hardcoded 1.3)
    const divisor = syncData.divisor || 1.3;
    const botBidEstimate = Math.round(botRawEstimate / divisor);
    const calculatorBidEstimate = syncData.bidEstimate;
    
    // Compare: must be IDENTICAL (zero tolerance)
    if (botBidEstimate !== calculatorBidEstimate) {
      console.error(`[FastBid] ❌ ESTIMATE DIVERGENCE: Bot=$${botBidEstimate} vs Calculator=$${calculatorBidEstimate} (divisor: ${divisor})`);
      return {
        verified: false,
        reason: 'estimate_mismatch',
        botEstimate: botBidEstimate,
        calculatorEstimate: calculatorBidEstimate,
        divergence: Math.abs(botBidEstimate - calculatorBidEstimate)
      };
    }
    
    // ✅ Perfect sync
    console.log(`[FastBid] ✅ Estimates synced: $${botBidEstimate} (Est: $${botRawEstimate} ÷ ${divisor})`);
    return {
      verified: true,
      botEstimate: botBidEstimate,
      calculatorEstimate: calculatorBidEstimate
    };
  }

  // Triple verification: Check 3 times with 1 second delay between checks
  // Ensures estimate is stable before allowing bidding on new lot
  async function tripleVerifyEstimateForNewLot(lotId) {
    if (verificationInProgress || verifiedLotId === lotId) {
      // Already verifying or already verified this lot
      return verifiedLotId === lotId;
    }

    verificationInProgress = true;
    console.log('[FastBid] 🔄 Starting triple verification for lot ' + lotId + '...');
    
    const checks = [];
    
    // Check 1
    let check1 = await verifySyncedEstimate();
    checks.push(check1);
    console.log('[FastBid] Check 1/3: ' + (check1.verified ? '✅' : '❌'));
    
    // Wait 1 second
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Check 2
    let check2 = await verifySyncedEstimate();
    checks.push(check2);
    console.log('[FastBid] Check 2/3: ' + (check2.verified ? '✅' : '❌'));
    
    // Wait 1 second
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Check 3
    let check3 = await verifySyncedEstimate();
    checks.push(check3);
    console.log('[FastBid] Check 3/3: ' + (check3.verified ? '✅' : '❌'));
    
    // All 3 must pass
    const allPassed = checks.every(c => c.verified);
    
    if (allPassed) {
      console.log('[FastBid] ✅✅✅ TRIPLE VERIFICATION PASSED - Lot ' + lotId + ' is safe for bidding');
      verifiedLotId = lotId;  // Mark lot as verified
      verificationInProgress = false;
      return true;
    } else {
      console.error('[FastBid] ❌ TRIPLE VERIFICATION FAILED - Lot ' + lotId + ' - Blocking bids');
      const failedChecks = checks.filter(c => !c.verified).map(c => c.reason).join(', ');
      console.error('[FastBid] Failed reasons: ' + failedChecks);
      verificationInProgress = false;
      return false;
    }
  }
  
  // Check sync every 2 seconds
  setInterval(async () => {
    if (!isMonitoring) return;
    
    const syncCheck = await verifySyncedEstimate();
    
    if (!syncCheck.verified && syncCheck.reason === 'estimate_mismatch') {
      // Divergence detected - log alert but don't reload
      console.error('[FastBid] 🚨 ESTIMATE MISMATCH - Possible issue detected');
      triggerExploit('ESTIMATE_MISMATCH', 
        `Bot=$${syncCheck.botEstimate} vs Calculator=$${syncCheck.calculatorEstimate} (Diff: $${syncCheck.divergence})`,
        [`Estimate divergence detected - ${syncCheck.reason}`]
      );
    }
  }, 2000);

})();
